// Netlify Function: /netlify/functions/ocr.js
// Backend nhỏ gọi Google Vision API — API key được giữ bí mật server-side

exports.handler = async (event) => {
  // Chỉ chấp nhận POST
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  // Lấy API key từ environment variable (cài trên Netlify, KHÔNG lưu trong code)
  const apiKey = process.env.GOOGLE_VISION_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'API key chưa được cấu hình' }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const { imageBase64, mimeType } = body;
  if (!imageBase64) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Thiếu imageBase64' }) };
  }

  // Gọi Google Vision API
  const visionUrl = `https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`;
  const requestBody = {
    requests: [{
      image: { content: imageBase64 },
      features: [
        { type: 'DOCUMENT_TEXT_DETECTION', maxResults: 1 }
      ],
      imageContext: {
        languageHints: ['vi', 'en'] // Ưu tiên tiếng Việt
      }
    }]
  };

  try {
    const response = await fetch(visionUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Vision API error:', errText);
      return {
        statusCode: response.status,
        body: JSON.stringify({ error: 'Google Vision API lỗi', detail: errText })
      };
    }

    const data = await response.json();
    const annotation = data.responses?.[0];

    // Trả về full text và word-level bounding boxes
    const fullText = annotation?.fullTextAnnotation?.text || '';
    const pages = annotation?.fullTextAnnotation?.pages || [];
    
    // Trích xuất words + confidence + bbox để highlight
    const words = [];
    pages.forEach(page => {
      page.blocks?.forEach(block => {
        block.paragraphs?.forEach(para => {
          para.words?.forEach(word => {
            const wordText = word.symbols?.map(s => s.text).join('') || '';
            const confidence = word.confidence || 0;
            const verts = word.boundingBox?.vertices || [];
            if (verts.length === 4 && wordText.trim()) {
              words.push({
                text: wordText,
                confidence: Math.round(confidence * 100),
                bbox: {
                  x0: verts[0].x || 0,
                  y0: verts[0].y || 0,
                  x1: verts[2].x || 0,
                  y1: verts[2].y || 0
                }
              });
            }
          });
        });
      });
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ fullText, words })
    };

  } catch (err) {
    console.error('Fetch error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Lỗi kết nối Google Vision API', detail: err.message })
    };
  }
};
