// Vercel Serverless Function: /api/ocr.js
// Gọi Google Vision API — API key được bảo mật server-side

export default async function handler(req, res) {
  // Chỉ chấp nhận POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Lấy API key từ environment variable (cài trên Vercel dashboard)
  const apiKey = process.env.GOOGLE_VISION_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'API key chưa được cấu hình trên Vercel' });
  }

  const { imageBase64, mimeType } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ error: 'Thiếu imageBase64' });
  }

  // Gọi Google Vision API
  const visionUrl = `https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`;
  const requestBody = {
    requests: [{
      image: { content: imageBase64 },
      features: [
        { type: 'DOCUMENT_TEXT_DETECTION', maxResults: 1 }
      ],
      imageContext: {
        languageHints: ['vi', 'en']
      }
    }]
  };

  try {
    const response = await fetch(visionUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({
        error: 'Google Vision API lỗi',
        detail: errText
      });
    }

    const data = await response.json();
    const annotation = data.responses?.[0];
    const fullText = annotation?.fullTextAnnotation?.text || '';
    const pages = annotation?.fullTextAnnotation?.pages || [];

    // Trích xuất words + confidence + bbox
    const words = [];
    pages.forEach(page => {
      page.blocks?.forEach(block => {
        block.paragraphs?.forEach(para => {
          para.words?.forEach(word => {
            const wordText = word.symbols?.map(s => s.text).join('') || '';
            const confidence = word.confidence || 0;
            const verts = word.boundingBox?.vertices || [];
            if (verts.length === 4 && wordText.trim()) {
              words.push({
                text: wordText,
                confidence: Math.round(confidence * 100),
                bbox: {
                  x0: verts[0].x || 0,
                  y0: verts[0].y || 0,
                  x1: verts[2].x || 0,
                  y1: verts[2].y || 0
                }
              });
            }
          });
        });
      });
    });

    return res.status(200).json({ fullText, words });

  } catch (err) {
    return res.status(500).json({
      error: 'Lỗi kết nối Google Vision API',
      detail: err.message
    });
  }
}
